package com.palo.control.biz;

import java.util.List;

import com.palo.model.bean.Goods;

public interface GoodsBiz {
	/**
	 * ������Ʒ
	 * @param goods
	 * @return
	 */
	public boolean addGoods(Goods goods);
	/**
	 * ɾ����Ʒ
	 * @param gid
	 * @return
	 */
	public boolean delGoods(int gid);
	/**
	 * �޸���Ʒ
	 * @param goods
	 * @return
	 */
	public boolean updateGoods(Goods goods);
	/**
	 * ��ѯ��Ʒ
	 * @return
	 */
	public List<Goods> queryGoods();
	/**
	 * ��ѯ��Ʒ
	 * @param cupage
	 * @param size
	 * @return
	 */
	public List<Goods> queryGoods(int cupage,int size);
	/**
	 * ������Ʒid��ѯ��Ʒ��Ϣ
	 * @param GID
	 * @return
	 */
	public Goods queryGoodsByGID(int GID);
	/**
	 * �������Ͳ�ѯ��Ʒ
	 * @param TID
	 * @param cupage
	 * @param size
	 * @return
	 */
	public List<Goods> queryGoodsByTID(int TID,int cupage,int size);
	/**
	 * ����key,name��ѯ��Ʒ
	 * @param search
	 * @param cupage
	 * @param size
	 * @return
	 */
	public List<Goods> queryGoodsBySearch(String search,int cupage,int size) ;
}
