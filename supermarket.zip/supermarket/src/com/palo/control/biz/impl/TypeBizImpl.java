package com.palo.control.biz.impl;

import java.util.List;

import com.palo.control.biz.TypeBiz;
import com.palo.model.bean.Type;
import com.palo.model.dao.TypeDao;
import com.palo.model.dao.impl.TypeDaoImpl;

public class TypeBizImpl implements TypeBiz {
	TypeDao typeDao = new TypeDaoImpl();
	public boolean addType(Type type) {
		// TODO Auto-generated method stub
		return typeDao.addType(type);
	}

	public boolean delType(int tid) {
		// TODO Auto-generated method stub
		return typeDao.delType(tid);
	}

	public boolean updateType(Type type) {
		// TODO Auto-generated method stub
		return typeDao.updateType(type);
	}

	public List<Type> queryType() {
		// TODO Auto-generated method stub
		return typeDao.queryType();
	}

	public Type queryTypeById(int tid) {
		// TODO Auto-generated method stub
		return typeDao.queryTypeByTID(tid);
	}

	public Type queryTypeByTname(String tname) {
		// TODO Auto-generated method stub
		return typeDao.queryTypeByTname(tname);
	}

}
