package com.palo.control.biz.impl;

import java.util.List;

import com.palo.control.biz.UserBiz;
import com.palo.model.bean.User;
import com.palo.model.dao.UserDao;
import com.palo.model.dao.impl.UserDaoImpl;

public class UserBizImpl implements UserBiz {
	UserDao userDao = new UserDaoImpl();
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}

	public boolean delUser(int UID) {
		// TODO Auto-generated method stub
		return userDao.delUser(UID);
	}

	public boolean editUser(User user) {
		// TODO Auto-generated method stub
		return userDao.updateUser(user);
	}

	public List<User> queryUser() {
		// TODO Auto-generated method stub
		return userDao.queryUser();
	}

}
