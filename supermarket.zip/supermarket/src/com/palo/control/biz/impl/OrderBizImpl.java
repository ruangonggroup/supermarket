package com.palo.control.biz.impl;

import java.util.List;

import com.palo.control.biz.OrderBiz;
import com.palo.model.bean.Goods;
import com.palo.model.bean.Orders;
import com.palo.model.bean.User;
import com.palo.model.dao.OrderDao;
import com.palo.model.dao.impl.OrderDaoImpl;

public class OrderBizImpl implements OrderBiz {
	OrderDao orderDao = new OrderDaoImpl();
	public boolean addOrder(Orders order, User user) {
		// TODO Auto-generated method stub
		return orderDao.addOrder(order, user);
	}

	public boolean delOrder(Orders orders) {
		// TODO Auto-generated method stub
		return orderDao.delOrder(orders);
	}

	public boolean update(Orders order) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<Orders> queryQrdersByONO(int ONO,String OTIME) {
		return orderDao.queryQrdersByONO(ONO, OTIME);
	}

	public List<Orders> queryOrdersByTime(String date,int cupage,int size) {
		// TODO Auto-generated method stub
		return orderDao.queryOrdersByTime(date,cupage,size);
	}

	public int queryOrderNum(String date) {
		// TODO Auto-generated method stub
		return orderDao.queryOrderNum(date);
	}

	public double queryOrderMoneyByDate(String date) {
		// TODO Auto-generated method stub
		return orderDao.queryOrderMoneyByDate(date);
	}

	public double queryOrderPureMoneyByDate(String date) {
		// TODO Auto-generated method stub
		return orderDao.queryOrderPureMoneyByDate(date);
	}

	public List<Goods> queryGoodsByDate(String date) {
		// TODO Auto-generated method stub
		return orderDao.queryGoodsByDate(date);
	}

}
