package com.palo.control.biz.impl;

import java.util.List;

import com.palo.control.biz.GoodsBiz;
import com.palo.model.bean.Goods;
import com.palo.model.dao.GoodsDao;
import com.palo.model.dao.impl.GoodsDaoImpl;
/**
 * ���ݷ��ʲ㣺
 * ��Ʒ����
 * @author Palo
 *
 */
public class GoodsBizImpl implements GoodsBiz {
	GoodsDao goodsDao = new GoodsDaoImpl();
	public boolean addGoods(Goods goods) {
		// TODO Auto-generated method stub
		return goodsDao.addGoods(goods);
	}

	public boolean delGoods(int gid) {
		// TODO Auto-generated method stub
		return goodsDao.delGoods(gid);
	}

	public boolean updateGoods(Goods goods) {
		// TODO Auto-generated method stub
		return goodsDao.updateGoods(goods);
	}

	public List<Goods> queryGoods() {
		// TODO Auto-generated method stub
		return goodsDao.queryGoods();
	}
	
	public List<Goods> queryGoods(int cupage, int size) {
		// TODO Auto-generated method stub
		return goodsDao.queryGoods(cupage, size);
	}

	public Goods queryGoodsByGID(int GID) {
		// TODO Auto-generated method stub
		return goodsDao.queryGoodsByGID(GID);
	}

	public List<Goods> queryGoodsByTID(int TID, int cupage, int size) {
		// TODO Auto-generated method stub
		return goodsDao.queryGoodsByTID(TID, cupage, size);
	}

	public List<Goods> queryGoodsBySearch(String search, int cupage, int size) {
		// TODO Auto-generated method stub
		return goodsDao.queryGoodsBySearch(search, cupage, size);
	}

}
