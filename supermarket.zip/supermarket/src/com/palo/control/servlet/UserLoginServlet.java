package com.palo.control.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.palo.model.bean.User;
import com.palo.model.dao.UserDao;
import com.palo.model.dao.impl.UserDaoImpl;

@SuppressWarnings("serial")
public class UserLoginServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		UserDao userDao = new UserDaoImpl();
		// TODO Auto-generated method stub
		User user = new User();
		user.setUSERNAME(req.getParameter("username"));
		user.setUSERPWD(req.getParameter("password"));
		String type = req.getParameter("type");
		User user2 = userDao.queryUserByUname(user.getUSERNAME());
		if(user2==null){
			if("1".equals(type)){
				resp.sendRedirect("index.jsp?err=1");
				return;
			}else{
				resp.sendRedirect("admin.jsp?err=1");
				return;
			}
		}else{
			if(user2.getUSERPWD().equals(user.getUSERPWD())){
				// ��user���󱣴���session
				HttpSession session = req.getSession();
				session.setAttribute("login-user", user2);
				session.setMaxInactiveInterval(-1);
				if(user2.getUAUTHORITY().equals("11")){
					resp.sendRedirect("admin.jsp");
				}else{
					resp.sendRedirect("sale.jsp");
				}
			}else{
				if("1".equals(type)){
					resp.sendRedirect("index.jsp?err=2");
					return;
				}else{
					resp.sendRedirect("admin.jsp?err=2");
					return;
				}
			}
		}
	}
	
}
