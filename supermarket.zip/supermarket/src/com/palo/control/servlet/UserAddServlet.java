package com.palo.control.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.UserBiz;
import com.palo.control.biz.impl.UserBizImpl;
import com.palo.model.bean.User;

public class UserAddServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		User user = new User();
		user.setUSERNAME(request.getParameter("username"));
		user.setUSERPWD(request.getParameter("userpwd"));
		if(request.getParameter("uauthority")!=null){
			user.setUAUTHORITY("01");
		}else{
			user.setUAUTHORITY("00");
		}
		if(request.getParameter("usernick")==null){
			user.setUSERNICK("δ����");
		}else{
			user.setUSERNICK(request.getParameter("usernick"));
		}
		UserBiz userBiz = new UserBizImpl();
		List<User> users = userBiz.queryUser();
		for (User user2 : users) {
			if(user2.getUSERNAME().equals(user.getUSERNAME())){
				response.sendRedirect("user-manage.jsp?id=1");
				return;
			}
		}
		if(userBiz.addUser(user)){
			response.sendRedirect("user-manage.jsp?id=2");
		}else{
			response.sendRedirect("user-manage.jsp?id=3");
		}
	}
}
