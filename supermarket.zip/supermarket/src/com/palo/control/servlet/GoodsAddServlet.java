package com.palo.control.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.GoodsBiz;
import com.palo.control.biz.impl.GoodsBizImpl;
import com.palo.model.bean.Goods;
import com.palo.model.bean.User;

public class GoodsAddServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		Goods goods = new Goods();
		goods.setGCOST(Double.parseDouble(request.getParameter("gcost")));
		goods.setGDISCOUNT(Integer.parseInt(request.getParameter("gdiscount")));
		goods.setGKEY(request.getParameter("gkey"));
		goods.setGNAME(request.getParameter("gname"));
		goods.setGNUMBER(Double.parseDouble(request.getParameter("gnumber")));
		goods.setGPRICE(Double.parseDouble(request.getParameter("gprice")));
		goods.setTID(Integer.parseInt(request.getParameter("tid")));
		
		GoodsBiz goodsBiz = new GoodsBizImpl();
		if(goodsBiz.addGoods(goods)){
			response.sendRedirect("goodslist.jsp?id=2");
		}else{
			response.sendRedirect("goodslist.jsp?id=3");
		}
	}
}
