package com.palo.control.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.TypeBiz;
import com.palo.control.biz.UserBiz;
import com.palo.control.biz.impl.TypeBizImpl;
import com.palo.control.biz.impl.UserBizImpl;
import com.palo.model.bean.Type;
import com.palo.model.bean.User;

public class TypeAddServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		Type type = new Type();
		type.setTNAME(request.getParameter("tname"));

		TypeBiz typeBiz = new TypeBizImpl();
		List<Type> types = typeBiz.queryType();
		for (Type type2 : types) {
			if(type2.getTNAME().equals(type.getTNAME())){
				response.sendRedirect("type-manage.jsp?id=1");
				return;
			}
		}
		if(typeBiz.addType(type)){
			response.sendRedirect("type-manage.jsp?id=2");
		}else{
			response.sendRedirect("type-manage.jsp?id=3");
		}
	}
}
