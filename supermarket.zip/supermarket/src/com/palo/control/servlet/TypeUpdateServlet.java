package com.palo.control.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.model.bean.Type;
import com.palo.model.dao.TypeDao;
import com.palo.model.dao.impl.TypeDaoImpl;

public class TypeUpdateServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		TypeDao typeDao = new TypeDaoImpl();
		Type type = new Type();
		try {
			type.setTID(Integer.parseInt(req.getParameter("tid")));
		} catch (NumberFormatException e) {
			resp.sendRedirect("type-manage.jsp?id=6");
			return;
		}
		type.setTNAME(req.getParameter("tname"));
		Type qtype = typeDao.queryTypeByTID(type.getTID());

		Type check = typeDao.queryTypeByTname(type.getTNAME());
		if(check==null||qtype.getTNAME().equals(type.getTNAME())){
			
		}else{
			resp.sendRedirect("type-manage.jsp?id=6");
			return;
		}
		
		qtype.setTNAME(type.getTNAME());
		
		if(typeDao.updateType(qtype)){
			resp.sendRedirect("type-manage.jsp?id=7");
		}else{
			resp.sendRedirect("type-manage.jsp?id=6");
		}
		
	}

}
