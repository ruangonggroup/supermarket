package com.palo.control.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.UserBiz;
import com.palo.control.biz.impl.UserBizImpl;

public class UserDeleteServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5387331055486335248L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		UserBiz userBiz = new UserBizImpl();
		if(req.getParameter("uid")==null){
			resp.sendRedirect("user-manage.jsp?id=4");
		}else{
			int uid;
			try {
				uid = Integer.parseInt(req.getParameter("uid"));
				if(userBiz.delUser(uid)){
					resp.sendRedirect("user-manage.jsp?id=5");
				}else{
					resp.sendRedirect("user-manage.jsp?id=4");
				}
			} catch (NumberFormatException e) {
				resp.sendRedirect("user-manage.jsp?id=4");
			}
		}
	}

}
