package com.palo.control.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.model.bean.Goods;
import com.palo.model.bean.Type;
import com.palo.model.dao.GoodsDao;
import com.palo.model.dao.impl.GoodsDaoImpl;

public class GoodsUpdateServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		GoodsDao goodsDao = new GoodsDaoImpl();
		Goods goods = new Goods();
		try {
			goods.setGID(Integer.parseInt(req.getParameter("gid")));
		} catch (NumberFormatException e) {
			resp.sendRedirect("goodslist.jsp?id=6");
			return;
		}
		goods.setGCOST(Double.parseDouble(req.getParameter("gcost")));
		goods.setGDISCOUNT(Integer.parseInt(req.getParameter("gdiscount")));
		goods.setGKEY(req.getParameter("gkey"));
		goods.setGNAME(req.getParameter("gname"));
		goods.setGNUMBER(Double.parseDouble(req.getParameter("gnumber")));
		goods.setGPRICE(Double.parseDouble(req.getParameter("gprice")));
		goods.setTID(Integer.parseInt(req.getParameter("tid")));
		if(goodsDao.updateGoods(goods)){
			resp.sendRedirect("goodslist.jsp?id=7");
		}else{
			resp.sendRedirect("goodslist.jsp?id=6");
		}
		
	}

}
