package com.palo.control.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.model.bean.User;
import com.palo.model.dao.UserDao;
import com.palo.model.dao.impl.UserDaoImpl;

public class UserUpdateServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		UserDao userDao = new UserDaoImpl();
		User user = new User();
		try {
			user.setUID(Integer.parseInt(req.getParameter("uid")));
		} catch (NumberFormatException e) {
			resp.sendRedirect("user-manage.jsp?id=6");
			return;
		}
		user.setUSERNAME(req.getParameter("username"));
		user.setUSERPWD(req.getParameter("userpwd"));
		user.setUSERNICK(req.getParameter("usernick"));
		User quer = userDao.queryUserByUid(user.getUID());

		User check = userDao.queryUserByUname(user.getUSERNAME());
		if(check==null||quer.getUSERNAME().equals(user.getUSERNAME())){
			
		}else{
			resp.sendRedirect("user-manage.jsp?id=6");
			return;
		}
		
		quer.setUSERNAME(user.getUSERNAME());
		quer.setUSERPWD(user.getUSERPWD());
		quer.setUSERNICK(user.getUSERNICK());
		if(req.getParameter("uauthority")!=null){
			quer.setUAUTHORITY(quer.getUAUTHORITY().substring(0,1)+"1");
		}else{
			quer.setUAUTHORITY(quer.getUAUTHORITY().substring(0,1)+"0");
		}
		if(userDao.updateUser(quer)){
			resp.sendRedirect("user-manage.jsp?id=7");
		}else{
			resp.sendRedirect("user-manage.jsp?id=6");
		}
		
	}

}
