package com.palo.control.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.TypeBiz;
import com.palo.control.biz.impl.TypeBizImpl;

public class TypeDeleteServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		TypeBiz typeBiz = new TypeBizImpl();
		if(req.getParameter("tid")==null){
			resp.sendRedirect("type-manage.jsp?id=4");
		}else{
			int tid;
			try {
				tid = Integer.parseInt(req.getParameter("tid"));
				if(typeBiz.delType(tid)){
					resp.sendRedirect("type-manage.jsp?id=5");
				}else{
					resp.sendRedirect("type-manage.jsp?id=4");
				}
			} catch (NumberFormatException e) {
				resp.sendRedirect("type-manage.jsp?id=4");
			}
		}
	}

}
