package com.palo.control.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.GoodsBiz;
import com.palo.control.biz.impl.GoodsBizImpl;

public class GoodsDeleteServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		GoodsBiz goodsBiz = new GoodsBizImpl();
		if(req.getParameter("gid")==null){
			resp.sendRedirect("goodslist.jsp?id=4");
		}else{
			int gid;
			try {
				gid = Integer.parseInt(req.getParameter("gid"));
				if(goodsBiz.delGoods(gid)){
					resp.sendRedirect("goodslist.jsp?id=5");
				}else{
					resp.sendRedirect("goodslist.jsp?id=4");
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
				resp.sendRedirect("goodslist.jsp?id=4");
			}
		}
	}

}
