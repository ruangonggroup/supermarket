package com.palo.control.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.GoodsBiz;
import com.palo.control.biz.OrderBiz;
import com.palo.control.biz.impl.GoodsBizImpl;
import com.palo.control.biz.impl.OrderBizImpl;
import com.palo.model.bean.Goods;
import com.palo.model.bean.Orders;
import com.palo.model.bean.User;

public class OrderPayServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public OrderPayServlet() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int i = 1;
		List<Orders> orders = new ArrayList<Orders>();
		GoodsBiz goodBiz = new GoodsBizImpl();
		OrderBiz orderBiz = new OrderBizImpl();
		String date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date()).toString();
		while(request.getParameter("gid_"+i)!=null){
			int ono = orderBiz.queryOrderNum(date.substring(0,10));
			Orders order = new Orders();
			order.setGID(Integer.parseInt(request.getParameter("gid_"+i)));
			Goods good = goodBiz.queryGoodsByGID(order.getGID());
			order.setONUM(Double.parseDouble(request.getParameter("gnum_"+i)));
			order.setOPRICE(good.getGPRICE()*(good.getGDISCOUNT()/100.0));
			order.setOTIME(date);
			order.setONO(ono+1);
			orders.add(order);
			i++;
		}
		User user =  (User)request.getSession().getAttribute("login-user");
		for (Orders order : orders) {
			orderBiz.addOrder(order,user);
		}
		response.sendRedirect("success.jsp");
	}

}
