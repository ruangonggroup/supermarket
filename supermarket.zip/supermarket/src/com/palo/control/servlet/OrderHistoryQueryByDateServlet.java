package com.palo.control.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.OrderBiz;
import com.palo.control.biz.impl.OrderBizImpl;
import com.palo.model.bean.Goods;
import com.palo.model.bean.Orders;

public class OrderHistoryQueryByDateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		String search = request.getParameter("search");
		
		String date = request.getParameter("date");
		int page = Integer.parseInt(request.getParameter("page"));
		OrderBiz orderBiz = new OrderBizImpl();
		List<Orders> orders = orderBiz.queryOrdersByTime(date,page,5);
		
		String json = "{\"orders\":[";
		for (int i = 0;i<orders.size();i++) {
			json += "{";
			json += "\"ONO\":\""+orders.get(i).getONO()+"\",";
			json += "\"OTIME\":\""+orders.get(i).getOTIME()+"\",";
			json += "\"UID\":\""+orders.get(i).getUID()+"\"";
			json+="}";
			if(i < orders.size()-1){
				json += ",";
			}
		}
		json += "]}";
		out.print(json);
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
