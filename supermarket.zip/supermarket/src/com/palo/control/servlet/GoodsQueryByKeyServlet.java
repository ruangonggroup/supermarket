package com.palo.control.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palo.control.biz.GoodsBiz;
import com.palo.control.biz.impl.GoodsBizImpl;
import com.palo.model.bean.Goods;

public class GoodsQueryByKeyServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		GoodsBiz goodsBiz = new GoodsBizImpl();
		request.setCharacterEncoding("utf-8");
		String search = request.getParameter("search");
		List<Goods> goods = goodsBiz.queryGoodsBySearch(search, 1, 10);
		response.setContentType("application/json;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		String json = "{\"goods\":[";
		for (int i = 0;i<goods.size();i++) {
			json += "{";
			json += "\"gid\":\""+goods.get(i).getGID()+"\",";
			json += "\"gname\":\""+goods.get(i).getGNAME()+"\",";
			json += "\"gkey\":\""+goods.get(i).getGKEY()+"\",";
			json += "\"gprice\":\""+goods.get(i).getGPRICE()+"\"";
			json+="}";
			if(i < goods.size()-1){
				json += ",";
			}
		}
		json += "]}";
		out.print(json);
		out.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
	

}
