package com.palo.model.bean;
/**
 * �����Ļ�����Ϣ��
 * @author Palo
 *
 */
public class OtherInfo {
	//Ӫҵ��
	private double MONEY;
	//����
	private double PUREMONEY;
	public OtherInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getMONEY() {
		return MONEY;
	}
	public void setMONEY(double mONEY) {
		MONEY = mONEY;
	}
	public double getPUREMONEY() {
		return PUREMONEY;
	}
	public void setPUREMONEY(double pUREMONEY) {
		PUREMONEY = pUREMONEY;
	}
	@Override
	public String toString() {
		return "OtherInfo [MONEY=" + MONEY + ", PUREMONEY=" + PUREMONEY + "]";
	}
	
}
