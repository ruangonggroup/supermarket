package com.palo.model.bean;
/**
 * �û�ʵ����
 * UID ���û�ID��
 * USERNAME ���û�����
 * USERPWD ���û����롿
 * USERNICK ���û��ǳơ�
 * UAUTHORITY��2�������û�0|����Ա1�����޸���ƷȨ�ޡ���
 * @author Palo
 *
 */
public class User {
	private int UID;
	private String USERNAME;
	private  String USERPWD;
	private String USERNICK;
	private String UAUTHORITY;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String uSERNAME, String uSERPWD, String uSERNICK,
			String uAUTHORITY) {
		super();
		USERNAME = uSERNAME;
		USERPWD = uSERPWD;
		USERNICK = uSERNICK;
		UAUTHORITY = uAUTHORITY;
	}
	public User(int uID, String uSERNAME, String uSERPWD, String uSERNICK,
			String uAUTHORITY) {
		super();
		UID = uID;
		USERNAME = uSERNAME;
		USERPWD = uSERPWD;
		USERNICK = uSERNICK;
		UAUTHORITY = uAUTHORITY;
	}
	public int getUID() {
		return UID;
	}
	public void setUID(int uID) {
		UID = uID;
	}
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getUSERPWD() {
		return USERPWD;
	}
	public void setUSERPWD(String uSERPWD) {
		USERPWD = uSERPWD;
	}
	public String getUSERNICK() {
		return USERNICK;
	}
	public void setUSERNICK(String uSERNICK) {
		USERNICK = uSERNICK;
	}
	public String getUAUTHORITY() {
		return UAUTHORITY;
	}
	public void setUAUTHORITY(String uAUTHORITY) {
		UAUTHORITY = uAUTHORITY;
	}
	@Override
	public String toString() {
		return "User [UID=" + UID + ", USERNAME=" + USERNAME + ", USERPWD="
				+ USERPWD + ", USERNICK=" + USERNICK + ", UAUTHORITY="
				+ UAUTHORITY + "]";
	}
	
}
