package com.palo.model.bean;
/**
 * TID ������ID��
 * TNAME ���������ơ�
 * @author Palo
 *
 */
public class Type {
	private int TID;
	private String TNAME;

	public Type() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Type(String TNAME) {
		super();
		this.TNAME = TNAME;
	}
	public Type(int tID, String TNAME) {
		super();
		TID = tID;
		this.TNAME = TNAME;
	}
	public int getTID() {
		return TID;
	}
	public void setTID(int tID) {
		TID = tID;
	}
	public String getTNAME() {
		return TNAME;
	}
	public void setTNAME(String TNAME) {
		this.TNAME = TNAME;
	}
	@Override
	public String toString() {
		return "Type [TID=" + TID + ", TNAME=" + TNAME + "]";
	}
	
	
}
