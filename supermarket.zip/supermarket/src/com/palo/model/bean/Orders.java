package com.palo.model.bean;
/**
 * ������
 * OID ������ID��
 * ONO �������š�170511#1��ʱ��#���ն����š�
 * OTIME ������ʱ�䡿
 * GID ����ƷID��
 * ONUM ����Ʒ������
 * OPRICE ���ܼۡ�
 * OSTATUS ���˶�״̬��
 * OTTIME ���˶�ʱ�䡿
 * OREASON ���˶�ԭ��
 * @author Palo
 *
 */
public class Orders {
	private int OID;
	private int ONO;
	private String OTIME;
	private int GID;
	private Double ONUM;
	private double OPRICE;
	private int OSTATUS;
	private String OTTIME;
	private String OREASON;
	private int UID;
	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getOID() {
		return OID;
	}
	public void setOID(int oID) {
		OID = oID;
	}
	public int getONO() {
		return ONO;
	}
	public void setONO(int oNO) {
		ONO = oNO;
	}
	public String getOTIME() {
		return OTIME;
	}
	public void setOTIME(String oTIME) {
		OTIME = oTIME;
	}
	public int getGID() {
		return GID;
	}
	public void setGID(int gID) {
		GID = gID;
	}
	public Double getONUM() {
		return ONUM;
	}
	public void setONUM(Double oNUM) {
		ONUM = oNUM;
	}
	public double getOPRICE() {
		return OPRICE;
	}
	public void setOPRICE(double oPRICE) {
		OPRICE = oPRICE;
	}
	public int getOSTATUS() {
		return OSTATUS;
	}
	public void setOSTATUS(int oSTATUS) {
		OSTATUS = oSTATUS;
	}
	public String getOTTIME() {
		return OTTIME;
	}
	public void setOTTIME(String oTTIME) {
		OTTIME = oTTIME;
	}
	public String getOREASON() {
		return OREASON;
	}
	public void setOREASON(String oREASON) {
		OREASON = oREASON;
	}
	public int getUID() {
		return UID;
	}
	public void setUID(int uID) {
		UID = uID;
	}
	public Orders(int oNO, String oTIME, int gID, Double oNUM, double oPRICE,
			int oSTATUS, String oTTIME, String oREASON, int uID) {
		super();
		ONO = oNO;
		OTIME = oTIME;
		GID = gID;
		ONUM = oNUM;
		OPRICE = oPRICE;
		OSTATUS = oSTATUS;
		OTTIME = oTTIME;
		OREASON = oREASON;
		UID = uID;
	}
	public Orders(int oID, int oNO, String oTIME, int gID, Double oNUM,
			double oPRICE, int oSTATUS, String oTTIME, String oREASON, int uID) {
		super();
		OID = oID;
		ONO = oNO;
		OTIME = oTIME;
		GID = gID;
		ONUM = oNUM;
		OPRICE = oPRICE;
		OSTATUS = oSTATUS;
		OTTIME = oTTIME;
		OREASON = oREASON;
		UID = uID;
	}
	@Override
	public String toString() {
		return "Orders [OID=" + OID + ", ONO=" + ONO + ", OTIME=" + OTIME
				+ ", GID=" + GID + ", ONUM=" + ONUM + ", OPRICE=" + OPRICE
				+ ", OSTATUS=" + OSTATUS + ", OTTIME=" + OTTIME + ", OREASON="
				+ OREASON + ", UID=" + UID + "]";
	}
	
	
}
