package com.palo.model.bean;
/**
 * ��Ʒ��
 * GID ����ƷID��
 * GNAME ����Ʒ���ơ�
 * GPRICE ����Ʒ���ۡ�
 * GNUMBER ����Ʒ������
 * GKEY�������롿
 * GDISCOUNT���ۿۡ�
 * GCOST ���ɱ���
 * TID ������ID��
 * @author Palo
 *
 */
public class Goods {
	private int GID;
	private String GNAME;
	private double GPRICE;
	private double GNUMBER;
	private String GKEY;
	private int GDISCOUNT;
	private double GCOST;
	private int TID;
	public Goods() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getGID() {
		return GID;
	}

	public void setGID(int gID) {
		GID = gID;
	}

	public String getGNAME() {
		return GNAME;
	}

	public void setGNAME(String gNAME) {
		GNAME = gNAME;
	}

	public double getGPRICE() {
		return GPRICE;
	}

	public void setGPRICE(double gPRICE) {
		GPRICE = gPRICE;
	}

	public double getGNUMBER() {
		return GNUMBER;
	}

	public void setGNUMBER(double gNUMBER) {
		GNUMBER = gNUMBER;
	}

	public String getGKEY() {
		return GKEY;
	}

	public void setGKEY(String gKEY) {
		GKEY = gKEY;
	}

	public int getGDISCOUNT() {
		return GDISCOUNT;
	}

	public void setGDISCOUNT(int gDISCOUNT) {
		GDISCOUNT = gDISCOUNT;
	}

	public double getGCOST() {
		return GCOST;
	}

	public void setGCOST(double gCOST) {
		GCOST = gCOST;
	}

	public int getTID() {
		return TID;
	}

	public void setTID(int tID) {
		TID = tID;
	}

	public Goods(int gID, String gNAME, double gPRICE, double gNUMBER,
			String gKEY, int gDISCOUNT, double gCOST, int tID) {
		super();
		GID = gID;
		GNAME = gNAME;
		GPRICE = gPRICE;
		GNUMBER = gNUMBER;
		GKEY = gKEY;
		GDISCOUNT = gDISCOUNT;
		GCOST = gCOST;
		TID = tID;
	}

	public Goods(String gNAME, double gPRICE, double gNUMBER, String gKEY,
			int gDISCOUNT, double gCOST, int tID) {
		super();
		GNAME = gNAME;
		GPRICE = gPRICE;
		GNUMBER = gNUMBER;
		GKEY = gKEY;
		GDISCOUNT = gDISCOUNT;
		GCOST = gCOST;
		TID = tID;
	}

	@Override
	public String toString() {
		return "Goods [GID=" + GID + ", GNAME=" + GNAME + ", GPRICE=" + GPRICE
				+ ", GNUMBER=" + GNUMBER + ", GKEY=" + GKEY + ", GDISCOUNT="
				+ GDISCOUNT + ", GCOST=" + GCOST + ", TID=" + TID + "]";
	}
	
}
