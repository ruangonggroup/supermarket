package com.palo.model.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.palo.model.bean.Type;
import com.palo.model.dao.BaseDao;
import com.palo.model.dao.TypeDao;
/**
 * 
 * @author Palo
 *
 */
public class TypeDaoImpl extends BaseDao implements TypeDao {

	public boolean addType(Type type) {
		String sql = "INSERT INTO TYPE(TNAME) VALUES(?)";
		List<Object> params = new ArrayList<Object>();
		params.add(type.getTNAME());
		return this.operUpdate(sql, params);
	}

	public boolean delType(int TID) {
		String sql = "DELETE FROM TYPE WHERE TID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(TID);
		return this.operUpdate(sql, params);
	}

	public boolean updateType(Type type) {
		String sql = "UPDATE TYPE SET TNAME = ? WHERE TID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(type.getTNAME());
		params.add(type.getTID());
		return this.operUpdate(sql, params);
	}

	public List<Type> queryType() {
		List<Type> types = new ArrayList<Type>();
		String sql = "SELECT * FROM TYPE";
		try {
			types =  this.operQuery(sql, null, Type.class);
		} catch (Exception e) {
			System.out.println("DAO:queryType is error.message:"+e.getMessage());
		}
		return types;
	}

	public Type queryTypeByTID(int TID) {
		List<Type> types = new ArrayList<Type>();
		String sql = "SELECT * FROM TYPE WHERE TID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(TID);
		try {
			types = this.operQuery(sql, params, Type.class);
		} catch (Exception e) {
			System.out.println("DAO:queryTypeByTID is error.message:"+e.getMessage());
		}
		if(types.size()>0){
			return types.get(0);
		}
		return null;
	}

	public Type queryTypeByTname(String tname) {
		List<Type> types = new ArrayList<Type>();
		String sql = "SELECT * FROM TYPE WHERE TNAME = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(tname);
		try {
			types = this.operQuery(sql, params, Type.class);
		} catch (Exception e) {
			System.out.println("DAO:queryTypeByTname is error.message:"+e.getMessage());
		}
		if(types.size()>0){
			return types.get(0);
		}
		return null;
	}

}
