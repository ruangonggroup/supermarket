package com.palo.model.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.palo.model.bean.Goods;
import com.palo.model.dao.BaseDao;
import com.palo.model.dao.GoodsDao;
/**
 * 
 * @author Palo
 *
 */
public class GoodsDaoImpl extends BaseDao implements GoodsDao {

	public boolean addGoods(Goods goods) {
		String sql = "INSERT INTO GOODS(GNAME,GPRICE,GNUMBER,GKEY,GDISCOUNT,GCOST,TID) VALUES(?,?,?,?,?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(goods.getGNAME());
		params.add(goods.getGPRICE());
		params.add(goods.getGNUMBER());
		params.add(goods.getGKEY());
		params.add(goods.getGDISCOUNT());
		params.add(goods.getGCOST());
		params.add(goods.getTID());
		return this.operUpdate(sql, params);
	}

	public boolean delGoods(int GID) {
		String sql = "DELETE FROM GOODS WHERE GID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(GID);
		return this.operUpdate(sql, params);
	}

	public boolean updateGoods(Goods goods) {
		String sql = "UPDATE GOODS SET GNAME = ?,GPRICE = ?,GNUMBER = ?,GKEY = ?,GDISCOUNT = ?,GCOST = ?,TID = ? WHERE GID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(goods.getGNAME());
		params.add(goods.getGPRICE());
		params.add(goods.getGNUMBER());
		params.add(goods.getGKEY());
		params.add(goods.getGDISCOUNT());
		params.add(goods.getGCOST());
		params.add(goods.getTID());
		params.add(goods.getGID());
		return this.operUpdate(sql, params);
	}
	
	public List<Goods> queryGoods() {
		List<Goods> goods = new ArrayList<Goods>();
		String sql = "SELECT * FROM GOODS ORDER BY GNAME ASC";
		try {
			goods = this.operQuery(sql, null, Goods.class);
		} catch (Exception e) {
			System.out.println("DAO:queryGoods is error.message:"+e.getMessage());
		}
		return goods;
	}

	public List<Goods> queryGoods(int cupage, int size) {
		List<Goods> goods = new ArrayList<Goods>();
		String sql = "SELECT * FROM GOODS ORDER BY GNAME ASC LIMIT ?,?";
		List<Object> params = new ArrayList<Object>();
		params.add((cupage-1)*size);
		params.add(size);
		try {
			goods = this.operQuery(sql, params, Goods.class);
		} catch (Exception e) {
			System.out.println("DAO:queryGoods is error.message:"+e.getMessage());
		}
		return goods;
	}

	public List<Goods> queryGoodsByTID(int TID, int cupage, int size) {
		List<Goods> goods = new ArrayList<Goods>();
		String sql = "SELECT * FROM GOODS WHERE TID = ? ORDER BY GNAME ASC LIMIT ?,?";
		List<Object> params = new ArrayList<Object>();
		params.add(TID);
		params.add((cupage-1)*size);
		params.add(size);
		try {
			goods = this.operQuery(sql, params, Goods.class);
		} catch (Exception e) {
			System.out.println("DAO:queryGoodsByTID is error.message:"+e.getMessage());
		}
		return goods;
	}

	public Goods queryGoodsByGID(int GID) {
		List<Goods> goods = new ArrayList<Goods>();
		String sql = "SELECT * FROM GOODS WHERE GID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(GID);
		try {
			goods = this.operQuery(sql, params, Goods.class);
		} catch (Exception e) {
			System.out.println("DAO:queryGoodsByGID is error.message:"+e.getMessage());
		}
		if(goods.size()>0){
			return goods.get(0);
		}
		return null;
	}

	public List<Goods> queryGoodsBySearch(String search,int cupage,int size) {
		List<Goods> goods = new ArrayList<Goods>();
		String sql = "SELECT * FROM GOODS WHERE GKEY LIKE ? OR GNAME LIKE ? ORDER BY GNAME ASC LIMIT ?,?";
		List<Object> params = new ArrayList<Object>();
		params.add(search+"%");
		params.add("%"+search+"%");
		params.add((cupage-1)*size);
		params.add(size);
		try {
			goods = this.operQuery(sql, params, Goods.class);
		} catch (Exception e) {
			System.out.println("DAO:queryGoodsBySearch is error.message:"+e.getMessage());
		}
		return goods;
	}

}
