package com.palo.model.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.palo.model.bean.User;
import com.palo.model.dao.BaseDao;
import com.palo.model.dao.UserDao;
/**
 * 
 * @author Palo
 *
 */
public class UserDaoImpl extends BaseDao implements UserDao {
	public boolean addUser(User user) {
		String sql = "INSERT INTO USER (USERNAME,USERPWD,USERNICK,UAUTHORITY) VALUES(?,?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(user.getUSERNAME());
		params.add(user.getUSERPWD());
		params.add(user.getUSERNICK());
		params.add(user.getUAUTHORITY());
		return this.operUpdate(sql, params);
	}

	public boolean delUser(int UID) {
		String sql = "DELETE FROM USER WHERE UID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(UID);
		return this.operUpdate(sql, params);
	}

	public boolean updateUser(User user) {
		String sql = "UPDATE USER SET USERNAME = ?,USERPWD = ?,USERNICK = ?,UAUTHORITY = ? WHERE UID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(user.getUSERNAME());
		params.add(user.getUSERPWD());
		params.add(user.getUSERNICK());
		params.add(user.getUAUTHORITY());
		params.add(user.getUID());
		return this.operUpdate(sql, params);
	}

	public List<User> queryUser() {
		List<User> users= new ArrayList<User>();
		String sql = "SELECT * FROM USER WHERE UAUTHORITY != '11'";
		try {
			users = this.operQuery(sql, null, User.class);
		} catch (Exception e) {
			System.out.println("DAO:queryUser is error.message:"+e.getMessage());
		}
		return users;
	}

	public User queryUserByUname(String uname) {
		List<User> users= new ArrayList<User>();
		String sql = "SELECT * FROM USER WHERE USERNAME = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(uname);
		try {
			users = this.operQuery(sql, params, User.class);
		} catch (Exception e) {
			System.out.println("DAO:queryUserByUname is error.message:"+e.getMessage());
			return null;
		}
		if(users.size()>0){
			return users.get(0);
		}
		return null;
	}

	public User queryUserByUid(int uid) {
		List<User> users= new ArrayList<User>();
		String sql = "SELECT * FROM USER WHERE UID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(uid);
		try {
			users = this.operQuery(sql, params, User.class);
		} catch (Exception e) {
			System.out.println("DAO:queryUserByUid is error.message:"+e.getMessage());
			return null;
		}
		if(users.size()>0){
			return users.get(0);
		}
		return null;
	}
}
