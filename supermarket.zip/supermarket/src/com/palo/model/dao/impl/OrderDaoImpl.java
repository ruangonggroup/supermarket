package com.palo.model.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.palo.control.biz.OrderBiz;
import com.palo.control.biz.impl.OrderBizImpl;
import com.palo.model.bean.Goods;
import com.palo.model.bean.Orders;
import com.palo.model.bean.OtherInfo;
import com.palo.model.bean.User;
import com.palo.model.dao.BaseDao;
import com.palo.model.dao.OrderDao;

public class OrderDaoImpl extends BaseDao implements OrderDao {

	public boolean addOrder(Orders order,User user) {
		String sql = "INSERT INTO ORDERS(ONO,OTIME,GID,ONUM,OPRICE,UID) VALUES(?,?,?,?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(order.getONO());
		params.add(order.getOTIME());
		params.add(order.getGID());
		params.add(order.getONUM());
		params.add(order.getOPRICE());
		params.add(user.getUID());
		return this.operUpdate(sql, params);
	}

	public boolean delOrder(Orders orders) {
		String sql = "UPDATE ORDERS SET OSTATUS = 1,OTTIME = ?,OREASON = ? WHERE ONO = ? and OTIME=? and GID = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date()).toString());
		params.add(orders.getOREASON());
		params.add(orders.getONO());
		params.add(orders.getOTIME());
		params.add(orders.getGID());
		return this.operUpdate(sql, params);
	}

	public boolean update(Orders order) {
		String sql = "UPDATE ORDERS SET ";
		return false;
	}

	public List<Orders> queryQrdersByONO(int ONO,String OTIME) {
		String sql = "SELECT * FROM ORDERS WHERE ONO = ? AND OTIME = ?";
		List<Object> params = new ArrayList<Object>();
		
		params.add(ONO);
		params.add(OTIME);
		List<Orders> obj = null;
		try {
			obj = this.operQuery(sql, params, Orders.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	public List<Orders> queryOrdersByTime(String date,int cupage, int size) {
		String sql = "SELECT DISTINCT ONO,OTIME,UID FROM ORDERS WHERE OTIME>? AND OTIME <? LIMIT ?,?";
		List<Object> params = new ArrayList<Object>();
		String startDate,endDate;
		if(date.length()==7){
			startDate = date + "-00";
			endDate = date + "-32";
		}else{
			startDate = ""+date;
			endDate = ""+date;
		}
		params.add(startDate+" 00:00:00");
		params.add(endDate+" 24:00:00");
		params.add((cupage-1)*size);
		params.add(size);
		List<Orders> obj = null;
		try {
			obj = this.operQuery(sql, params, Orders.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	public int queryOrderNum(String date) {
		// TODO Auto-generated method stub
		String sql = "select DISTINCT ONO,OTIME FROM ORDERS WHERE OTIME>? AND OTIME <?";
		List<Object> params = new ArrayList<Object>();
		String startDate,endDate;
		if(date.length()==7){
			startDate = date + "-00";
			endDate = date + "-32";
		}else{
			startDate = ""+date;
			endDate = ""+date;
		}
		params.add(startDate+" 00:00:00");
		params.add(endDate+" 24:00:00");
		try {
			List<Orders> obj = this.operQuery(sql, params, Orders.class);
			
			if(obj.size()==0){
				return 0; 
			}else{
				if(date.length()==7){
					int count;
					return obj.size();
				}else{
					int max = 0;
					for (Orders orders : obj) {
						if(max<orders.getONO()){
							max = orders.getONO();
						}
					}
					return max;
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public double queryOrderMoneyByDate(String date) {
		// TODO Auto-generated method stub
		String sql = "SELECT SUM(OPRICE*ONUM) MONEY FROM ORDERS WHERE OTIME > ? AND OTIME < ? AND OSTATUS = 0";
		List<Object> params = new ArrayList<Object>();
		String startDate,endDate;
		if(date.length()==7){
			startDate = date + "-00";
			endDate = date + "-32";
		}else{
			startDate = ""+date;
			endDate = ""+date;
		}
		params.add(startDate+" 00:00:00");
		params.add(endDate+" 24:00:00");
		List<OtherInfo> obj = null;
		try {
			obj = this.operQuery(sql, params, OtherInfo.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		return obj.get(0).getMONEY();
	}

	public double queryOrderPureMoneyByDate(String date) {
		String sql = "SELECT SUM(G.GCOST*O.ONUM) PUREMONEY FROM ORDERS O,GOODS G WHERE OTIME > ? AND OTIME < ? AND OSTATUS = 0 AND G.GID = O.GID";
		List<Object> params = new ArrayList<Object>();
		String startDate,endDate;
		if(date.length()==7){
			startDate = date + "-00";
			endDate = date + "-32";
		}else{
			startDate = ""+date;
			endDate = ""+date;
		}
		params.add(startDate+" 00:00:00");
		params.add(endDate+" 24:00:00");
		List<OtherInfo> obj = null;
		try {
			obj = this.operQuery(sql, params, OtherInfo.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		return obj.get(0).getPUREMONEY();
	}

	public List<Goods> queryGoodsByDate(String date) {
		// TODO Auto-generated method stub
		String sql = "SELECT G.GNAME GNAME,O.ONUM GNUMBER,O.OPRICE GPRICE FROM GOODS G,ORDERS O WHERE O.GID = G.GID AND O.OTIME > ? AND O.OTIME < ? AND O.OSTATUS = 0 ORDER BY GNAME";
		List<Object> params = new ArrayList<Object>();
		String startDate,endDate;
		if(date.length()==7){
			startDate = date + "-00";
			endDate = date + "-32";
		}else{
			startDate = ""+date;
			endDate = ""+date;
		}
		params.add(startDate+" 00:00:00");
		params.add(endDate+" 24:00:00");
		List<Goods> obj = null;
		try {
			obj = this.operQuery(sql, params, Goods.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		if(obj.size()!=0){
			List<Goods> goods = new ArrayList<Goods>();
			Goods good = obj.get(0);
			String name;
			for (int i = 1; i < obj.size(); i++) {
				if(good.getGNAME().equals(obj.get(i).getGNAME())){
					good.setGNUMBER(good.getGNUMBER()+obj.get(i).getGNUMBER());
				}else{
					goods.add(good);
					good = obj.get(i);
				}
				
			}
			goods.add(good);
			return goods;
		}
		return obj;
	}
}
